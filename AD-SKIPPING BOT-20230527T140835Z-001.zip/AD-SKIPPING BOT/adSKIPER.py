import pyautogui
import time
import os

pyautogui.FAILSAFE = True
path = "img\\play.png"  # It detects this image on screen (skip ad screenshot)

def findAndClick():
    for i in range(50):
        time.sleep(0.45) # this timer help the program to not destroy my pc's RAM by running 100's of time in one sec
        videoAdCords = pyautogui.locateCenterOnScreen(path, confidence=0.97) #(if it is 97% sure then it will click on it)
        print(videoAdCords) # this prints if it found a match on screen

        if videoAdCords  is not None:
            break # and if not then it will stop

    if videoAdCords is not None:
        pyautogui.click(videoAdCords) # this line helps to click on it (pyautogui is awesome)
        os.abort() # and after clicking i ordered it to stop the program (because its for virtual assistant)
        

    # time.sleep(1)
    # findAndClick()


findAndClick() # it calls the main function